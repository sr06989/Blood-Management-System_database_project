﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class request_form : Form
    {
        DBAccess objdBAccess = new DBAccess();
        DataTable dtUsers = new DataTable();
        public request_form()
        {
            InitializeComponent();
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string blogp = textBox1.Text;
            string quantity = textBox2.Text;
            if (blogp.Equals(""))
            {
                MessageBox.Show("Please Enter your blood group");
            }
            else if (quantity.Equals(""))
            {
                MessageBox.Show("Please Enter your quantity");
            }
            else
            {
                string query = "Select * from Request where bloodgroup_type= '" + blogp + "'AND quantities_bottle = '" + quantity + "'";

                objdBAccess.readDatathroughAdapter(query, dtUsers);

                if (dtUsers.Rows.Count == 1)
                {
                    MessageBox.Show("Your Request was submitted. Contact on 012-456-789 for further details.!");
                    objdBAccess.closeConn();
                    this.Hide();
                    sel_form selec = new sel_form();
                    selec.Show();
                }
                else
                {
                    MessageBox.Show("Your Request had an error. Contact on 012-456-789 for further details.!");
                    this.Hide();
                    sel_form selec = new sel_form();
                    selec.Show();
                }
            }
        }

        private void request_form_Load(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

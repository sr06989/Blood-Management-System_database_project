﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class sel_form : Form
    {
        public sel_form()
        {
            InitializeComponent();
        }

        

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            donor don = new donor();
            don.Show();


            


        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            request_form req = new request_form();
            req.Show();
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login btt = new Login();
            btt.Show();
        }

        private void sel_form_Load(object sender, EventArgs e)
        {

        }
    }
}

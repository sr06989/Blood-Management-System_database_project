﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class donor : Form
    {
        DBAccess objdBAccess = new DBAccess();
        //DataTable dtUsers = new DataTable();
        public donor()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //sel_form open_2 = new sel_form();
            //open1.ShowDialog();
            //open_2.Show()
            string id = textBox3.Text;
            string name = textBox2.Text;
            string bloodgrp = textBox4.Text;
            string quantity = numericUpDown1.Text;
            string donationdate = textBox1.Text;



            //string dondate = textBox1.Text;

            if (name.Equals(""))
            {
                MessageBox.Show("Please Enter your name");
            }
            else
            {
                SqlCommand insertCommand = new SqlCommand("insert into blood_bank(blood_bank_id, name, blood_group, quantity, donation_date) values(@id, @name, @bloodgrp, @quantity, @donationdate)");
                insertCommand.Parameters.AddWithValue("@name", name);
                insertCommand.Parameters.AddWithValue("@id", id);
                insertCommand.Parameters.AddWithValue("@bloodgrp", bloodgrp);
                insertCommand.Parameters.AddWithValue("@quantity", quantity);
                insertCommand.Parameters.AddWithValue("@donationdate", donationdate);
                
                

                int row = objdBAccess.executeQuery(insertCommand);

                if (row == 1)
                {
                    MessageBox.Show("Donation done, successfully, Thank you for visiting us!");
                    this.Hide();
                    sel_form selec = new sel_form();
                    selec.Show();
                    
                }
                else
                {
                    MessageBox.Show("Donation wasn't, successful, Thank you for visiting us! Contact 123-876-987");
                    this.Hide();
                    sel_form selec = new sel_form();
                    selec.Show();
                }





            }

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class emp_form : Form
    {
        DBAccess objdBAccess = new DBAccess();
        public emp_form()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string id = textBox2.Text;
            string empname = textBox1.Text;
            string date = textBox4.Text;
            string address = textBox3.Text;
            string phone = textBox6.Text;
            string salary = textBox5.Text;
            string loginid = textBox7.Text;
            string password = textBox8.Text;
            if (empname.Equals(""))
            {
                MessageBox.Show("Please Enter your name");
            }
            else
            {
                SqlCommand insertCommand = new SqlCommand("insert into employees(idemployees, employee_name, date_of_birth, employee_address, employee_phone, salary, loginid, login_password) values(@id, @empname, @date, @address, @phone, @salary, @loginid, @password)");
                insertCommand.Parameters.AddWithValue("@empname", empname);
                insertCommand.Parameters.AddWithValue("@id", id);
                insertCommand.Parameters.AddWithValue("@date", date);
                insertCommand.Parameters.AddWithValue("@address", address);
                insertCommand.Parameters.AddWithValue("@phone", phone);
                insertCommand.Parameters.AddWithValue("@salary", salary);
                insertCommand.Parameters.AddWithValue("@loginid", loginid);
                insertCommand.Parameters.AddWithValue("@password", password);


                int row = objdBAccess.executeQuery(insertCommand);

                if (row == 1)
                {
                    MessageBox.Show("Signed up, successfully");
                    this.Hide();
                    sel_form selec = new sel_form();
                    selec.Show();
                }


            }

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class sign_form : Form
    {
        
        DBAccess objdBAccess = new DBAccess();
        public sign_form()
        {
            InitializeComponent();
        }

        private void sign_form_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            emp_form bttn = new emp_form();
            bttn.Show();

        }

        private void label10_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            string name = textBox1.Text;
            string id = textBox7.Text;
            string bloodgroup = textBox2.Text;
            string phone = textBox3.Text;
            string city = textBox4.Text;
            string address = textBox5.Text;
            
            string cnic = textBox6.Text;
            string loginid = textBox9.Text;
            string password = textBox8.Text;


            if (name.Equals(""))
            {
                MessageBox.Show("Please Enter your name");
            }
            else
            {
                SqlCommand insertCommand = new SqlCommand("insert into donor(donor_id, name, blood_group,phone_no,cnic, location, city, login_id_donor, login_password) values(@id, @name, @bloodgroup, @phone, @cnic, @address, @city, @loginid, @password)");
                insertCommand.Parameters.AddWithValue("@name", name);
                insertCommand.Parameters.AddWithValue("@id", id);
                insertCommand.Parameters.AddWithValue("@bloodgroup", bloodgroup);
                insertCommand.Parameters.AddWithValue("@phone", phone);
                insertCommand.Parameters.AddWithValue("@city", city);
                insertCommand.Parameters.AddWithValue("@address", address);
                insertCommand.Parameters.AddWithValue("@cnic", cnic);
                insertCommand.Parameters.AddWithValue("@loginid", loginid);
                insertCommand.Parameters.AddWithValue("@password", password);

                int row = objdBAccess.executeQuery(insertCommand);

                if (row==1)
                {
                    MessageBox.Show("Signed up, successfully");
                    this.Hide();
                    sel_form selec = new sel_form();
                    selec.Show();
                }
                




            }
            


        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            string id = textBox7.Text;
            string bloodgroup = textBox2.Text;
            string phone = textBox3.Text;
            string city = textBox4.Text;
            string address = textBox5.Text;

            string cnic = textBox6.Text;
            string loginid = textBox9.Text;
            string password = textBox8.Text;

            SqlCommand insertCommand = new SqlCommand("insert into patient_recipient(patient_id, patient_name, blood_group,phone_no,cnic, location, city, login_id_patient, login_password) values(@id, @name, @bloodgroup, @phone, @cnic, @address, @city, @loginid, @password)");
            insertCommand.Parameters.AddWithValue("@name", name);
            insertCommand.Parameters.AddWithValue("@id", id);
            insertCommand.Parameters.AddWithValue("@bloodgroup", bloodgroup);
            insertCommand.Parameters.AddWithValue("@phone", phone);
            insertCommand.Parameters.AddWithValue("@city", city);
            insertCommand.Parameters.AddWithValue("@address", address);
            insertCommand.Parameters.AddWithValue("@cnic", cnic);
            insertCommand.Parameters.AddWithValue("@loginid", loginid);
            insertCommand.Parameters.AddWithValue("@password", password);

            int row = objdBAccess.executeQuery(insertCommand);

            if (row == 1)
            {
                MessageBox.Show("Signed up, successfully");
                this.Hide();
                sel_form selec = new sel_form();
                selec.Show();
            }
        }
    }
}

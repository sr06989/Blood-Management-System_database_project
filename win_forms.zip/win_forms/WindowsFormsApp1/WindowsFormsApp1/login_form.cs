﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Login : Form
    {
        DBAccess objdBAccess = new DBAccess();
        DataTable dtUsers = new DataTable();
        DataTable dUsers = new DataTable();
        DataTable dsUsers = new DataTable();
        public Login()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txt_password_TextChanged(object sender, EventArgs e)
        {
            if (txt_password.PasswordChar == '\0')
            {
                txt_password.PasswordChar = '*';
            }
        }

        private void txt_id_TextChanged(object sender, EventArgs e)
        {

        }

        private void bttn_login_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("ITS ALIVE !!!!");
            string id = txt_id.Text;
            string pw = txt_password.Text;
            MessageBox.Show("The id is : " + id);
            MessageBox.Show("The id password is : " + pw);
            sel_form open_2 = new sel_form();
            open_2.Show();

        

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            


        }

        private void bttn_login_Click_1(object sender, EventArgs e)
        {
            //sel_form open_2 = new sel_form();
            //open1.ShowDialog();
            //open_2.Show()
            string email = txt_id.Text;
            string password = txt_password.Text;

            if (email.Equals(""))
            {
                MessageBox.Show("Please Enter your email");
            }
            if (password.Equals(""))
            {
                MessageBox.Show("Please Enter your password");
            }
            else
            {
                string query = "Select * from donor where login_id_donor= '" + email + "'AND login_password = '" + password + "'";

                objdBAccess.readDatathroughAdapter(query, dtUsers);

                if (dtUsers.Rows.Count == 1)
                {
                    MessageBox.Show("Congratulations, you are logged in!");
                    objdBAccess.closeConn();
                    this.Hide();
                    sel_form selec = new sel_form();
                    selec.Show();
                }

                string query2 = "Select * from employees where loginid= '" + email + "'AND login_password = '" + password + "'";
                objdBAccess.readDatathroughAdapter(query2, dUsers);

                if (dUsers.Rows.Count == 1)
                {
                    MessageBox.Show("Congratulations, you are logged in!");
                    objdBAccess.closeConn();
                    this.Hide();
                    sel_form selec = new sel_form();
                    selec.Show();
                }

                string query3 = "Select * from Patient_recipient where login_id_patient= '" + email + "'AND login_password = '" + password + "'";
                objdBAccess.readDatathroughAdapter(query3, dsUsers);

                if (dsUsers.Rows.Count == 1)
                {
                    MessageBox.Show("Congratulations, you are logged in!");
                    objdBAccess.closeConn();
                    this.Hide();
                    sel_form selec = new sel_form();
                    selec.Show();
                }
            }
            


        }
            

        private void button1_Click_1(object sender, EventArgs e)
        {
            sign_form open_1 = new sign_form();
            //open1.ShowDialog();
            open_1.Show();
        }

        private void txt_id_TextChanged_1(object sender, EventArgs e)
        {

        }
    }
}

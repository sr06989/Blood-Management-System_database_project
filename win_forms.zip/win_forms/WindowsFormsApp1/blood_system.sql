CREATE TABLE medication (
  idmedication INTEGER   NOT NULL ,
  medication_name VARCHAR(100)    ,
  medication_description VARCHAR(100)      ,
PRIMARY KEY(idmedication));




CREATE TABLE medical_condition (
  medical_conId INTEGER   NOT NULL ,
  condition_name VARCHAR(100)    ,
  condition_description VARCHAR(100)     ,
PRIMARY KEY(medical_conId));




CREATE TABLE donor (
  donor_id INTEGER   NOT NULL ,
  name VARCHAR(100)    ,
  blood_group VARCHAR(100)    ,
  phone_no VARCHAR(100)    ,
  cnic INTEGER  ,
  location VARCHAR (100)   ,
  city VARCHAR (100)   ,
  login_id_donor VARCHAR (100)    ,
  login_password VARCHAR  (100)    ,
PRIMARY KEY(donor_id));



CREATE TABLE Patient_recipient (
  patient_id INTEGER   NOT NULL ,
  patient_name VARCHAR(100)  ,
  city VARCHAR (100)    ,
  blood_group  VARCHAR (100)    ,
  phone_no VARCHAR  (100)   ,
  location VARCHAR (100) ,
  cnic VARCHAR (100) ,
  login_id_patient VARCHAR (100)   ,
  login_password VARCHAR  (100)    ,
PRIMARY KEY(patient_id));




CREATE TABLE employees (
  idemployees INTEGER   NOT NULL ,
  employee_name VARCHAR (100)    ,
  date_of_birth DATETIME    ,
  employee_address VARCHAR (100)    ,
  employee_phone VARCHAR  (100)   ,
  salary  FLOAT    ,
  loginid VARCHAR  (100)   ,
  login_password VARCHAR  (100)     ,
PRIMARY KEY(idemployees));



CREATE TABLE donor_has_medication (
  medication_idmedication INTEGER   NOT NULL ,
  donor_id INTEGER   NOT NULL   ,
PRIMARY KEY(medication_idmedication, donor_id)    ,
  FOREIGN KEY(donor_id)
    REFERENCES donor(donor_id),
  FOREIGN KEY(medication_idmedication)
    REFERENCES medication(idmedication));


CREATE INDEX donor_has_medication_FKIndex1 ON donor_has_medication (donor_id);
CREATE INDEX donor_has_medication_FKIndex2 ON donor_has_medication (medication_idmedication);


CREATE INDEX IFK_Rel_11 ON donor_has_medication (donor_id);
CREATE INDEX IFK_Rel_12 ON donor_has_medication (medication_idmedication);


CREATE TABLE Request (
  Request_id INTEGER   NOT NULL ,
  request_date VARCHAR (100)    ,
  bloodgroup_type  VARCHAR (100)    ,
  quantities_bottle  INTEGER    ,
  donor_status BIT    ,
  donor_id INTEGER      ,
  patient_id INTEGER    ,
  PRIMARY KEY(Request_id));


CREATE TABLE donor_has_medical_condition (
  medical_condition_medical_conId INTEGER   NOT NULL ,
  donor_id INTEGER   NOT NULL   ,
PRIMARY KEY(medical_condition_medical_conId, donor_id)    ,
  FOREIGN KEY(donor_id)
    REFERENCES donor(donor_id),
  FOREIGN KEY(medical_condition_medical_conId)
    REFERENCES medical_condition(medical_conId));


CREATE INDEX donor_has_medical_condition_FKIndex1 ON donor_has_medical_condition (donor_id);
CREATE INDEX donor_has_medical_condition_FKIndex2 ON donor_has_medical_condition (medical_condition_medical_conId);


CREATE INDEX IFK_Rel_13 ON donor_has_medical_condition (donor_id);
CREATE INDEX IFK_Rel_14 ON donor_has_medical_condition (medical_condition_medical_conId);




CREATE TABLE Blood_Bank (
  blood_bank_id INTEGER   NOT NULL ,
  name VARCHAR (100)    ,
  blood_group VARCHAR (100)    ,
  quantity  INTEGER    ,
  donation_date DATETIME    ,
  exp_date DATETIME ,
PRIMARY KEY(blood_bank_id));